const rooms = [
  {
    id: "deluxe",
    name: "Deluxe Room",
    capacity: 2,
    price: 850000,
    image: "https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=900&q=80",
    description: "Kamar elegan untuk dua tamu dengan pencahayaan hangat dan area kerja ringkas.",
    amenities: ["Sarapan", "Wi-Fi", "Queen bed", "City view"]
  },
  {
    id: "family",
    name: "Family Room",
    capacity: 4,
    price: 1250000,
    image: "https://images.unsplash.com/photo-1587737180533-7157a8b32b8d?auto=format&fit=crop&w=900&q=80",
    description: "Ruang lapang untuk keluarga dengan dua tempat tidur dan area santai.",
    amenities: ["Sarapan", "Wi-Fi", "2 bed", "Mini pantry"]
  },
  {
    id: "executive",
    name: "Executive Suite",
    capacity: 2,
    price: 1450000,
    image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=900&q=80",
    description: "Suite tenang dengan sofa, meja kerja, dan layanan prioritas.",
    amenities: ["Sarapan", "Lounge", "King bed", "Bathtub"]
  },
  {
    id: "presidential",
    name: "Presidential Suite",
    capacity: 6,
    price: 2400000,
    image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=900&q=80",
    description: "Pilihan paling luas dengan ruang keluarga privat dan pemandangan terbaik hotel.",
    amenities: ["Butler", "Private lounge", "King bed", "Panorama"]
  }
];

const BCA_ACCOUNT = "71898188199198872";
const BCA_ACCOUNT_NAME = "Pian Hotel";
const QRIS_IMAGE = "assets/qris-demo.svg";

const state = {
  checkIn: "",
  checkOut: "",
  guestCount: 2,
  nights: 0,
  selectedRoom: null,
  guest: null
};

const currency = new Intl.NumberFormat("id-ID", {
  style: "currency",
  currency: "IDR",
  maximumFractionDigits: 0
});

const dateFormat = new Intl.DateTimeFormat("id-ID", {
  day: "2-digit",
  month: "long",
  year: "numeric"
});

const roomList = document.querySelector("#roomList");
const searchForm = document.querySelector("#searchForm");
const guestForm = document.querySelector("#guestForm");
const paymentForm = document.querySelector("#paymentForm");
const summaryBox = document.querySelector("#summaryBox");
const searchMessage = document.querySelector("#searchMessage");
const guestMessage = document.querySelector("#guestMessage");
const paymentMessage = document.querySelector("#paymentMessage");
const guestSection = document.querySelector("#guestSection");
const paymentSection = document.querySelector("#paymentSection");
const confirmationSection = document.querySelector("#konfirmasi");
const confirmationBox = document.querySelector("#confirmationBox");
const newBookingButton = document.querySelector("#newBookingButton");
const printTicketButton = document.querySelector("#printTicketButton");
const paymentMethodSelect = document.querySelector("#paymentMethod");
const paymentInstruction = document.querySelector("#paymentInstruction");

function initReservationPage() {
  if (!roomList) {
    return;
  }

  setMinimumDates();
  renderRooms(rooms);
  restoreLastBooking();
  updateSummary();

  searchForm.addEventListener("submit", handleSearch);
  guestForm.addEventListener("submit", handleGuestSubmit);
  paymentForm.addEventListener("submit", handlePaymentSubmit);
  paymentMethodSelect.addEventListener("change", renderPaymentInstruction);
  newBookingButton.addEventListener("click", resetBooking);
  printTicketButton.addEventListener("click", printTicket);
}

function setMinimumDates() {
  const today = toDateInputValue(new Date());
  document.querySelector("#checkIn").min = today;
  document.querySelector("#checkOut").min = today;
}

function handleSearch(event) {
  event.preventDefault();

  const checkIn = document.querySelector("#checkIn").value;
  const checkOut = document.querySelector("#checkOut").value;
  const guestCount = Number(document.querySelector("#guestCount").value);
  const validation = validateSearch(checkIn, checkOut, guestCount);

  if (!validation.valid) {
    showMessage(searchMessage, validation.message);
    return;
  }

  state.checkIn = checkIn;
  state.checkOut = checkOut;
  state.guestCount = guestCount;
  state.nights = validation.nights;
  state.selectedRoom = null;
  state.guest = null;

  const availableRooms = rooms.filter((room) => room.capacity >= guestCount);
  renderRooms(availableRooms);
  hideSectionsAfterSearch();
  updateSummary();
  setStep(2);
  showMessage(searchMessage, `${availableRooms.length} kamar tersedia untuk ${guestCount} tamu.`, true);
}

function validateSearch(checkIn, checkOut, guestCount) {
  if (!checkIn || !checkOut) {
    return { valid: false, message: "Tanggal check-in dan check-out wajib diisi." };
  }

  const today = stripTime(new Date());
  const start = parseInputDate(checkIn);
  const end = parseInputDate(checkOut);

  if (start < today) {
    return { valid: false, message: "Tanggal check-in tidak boleh sebelum hari ini." };
  }

  if (end <= start) {
    return { valid: false, message: "Tanggal check-out harus setelah check-in." };
  }

  if (!Number.isInteger(guestCount) || guestCount < 1 || guestCount > 6) {
    return { valid: false, message: "Jumlah tamu harus antara 1 sampai 6 orang." };
  }

  return {
    valid: true,
    nights: Math.round((end - start) / 86400000)
  };
}

function renderRooms(roomItems) {
  if (!roomItems.length) {
    roomList.innerHTML = `<p class="form-message">Tidak ada kamar yang sesuai dengan jumlah tamu.</p>`;
    return;
  }

  roomList.innerHTML = roomItems.map((room) => `
    <article class="room-card ${state.selectedRoom?.id === room.id ? "selected" : ""}">
      <img src="${room.image}" alt="${room.name}">
      <div class="room-body">
        <div class="room-top">
          <div>
            <h3>${room.name}</h3>
            <p>${room.description}</p>
          </div>
          <div class="price">${currency.format(room.price)}<br><small>/ malam</small></div>
        </div>
        <div class="amenities">
          <span class="capacity-pill">Maks. ${room.capacity} tamu</span>
          ${room.amenities.map((item) => `<span>${item}</span>`).join("")}
        </div>
        <div class="room-actions">
          <span>${state.nights ? `${state.nights} malam: ${currency.format(room.price * state.nights)}` : "Masukkan tanggal untuk hitung total"}</span>
          <button class="primary-button" type="button" data-room-id="${room.id}">Pilih Kamar</button>
        </div>
      </div>
    </article>
  `).join("");

  roomList.querySelectorAll("[data-room-id]").forEach((button) => {
    button.addEventListener("click", () => selectRoom(button.dataset.roomId));
  });
}

function selectRoom(roomId) {
  if (!state.checkIn || !state.checkOut || !state.nights) {
    showMessage(searchMessage, "Cari tanggal menginap terlebih dahulu sebelum memilih kamar.");
    window.scrollTo({ top: 0, behavior: "smooth" });
    return;
  }

  state.selectedRoom = rooms.find((room) => room.id === roomId);
  renderRooms(rooms.filter((room) => room.capacity >= state.guestCount));
  guestSection.classList.remove("hidden");
  paymentSection.classList.add("hidden");
  confirmationSection.classList.add("hidden");
  updateSummary();
  setStep(3);
}

function handleGuestSubmit(event) {
  event.preventDefault();

  if (!state.selectedRoom) {
    showMessage(guestMessage, "Pilih kamar terlebih dahulu.");
    return;
  }

  const guest = {
    name: document.querySelector("#guestName").value.trim(),
    email: document.querySelector("#guestEmail").value.trim(),
    phone: document.querySelector("#guestPhone").value.trim()
  };

  if (!guest.name || !guest.email || !guest.phone) {
    showMessage(guestMessage, "Semua data tamu wajib diisi.");
    return;
  }

  if (!guest.email.includes("@")) {
    showMessage(guestMessage, "Format email belum benar.");
    return;
  }

  state.guest = guest;
  paymentSection.classList.remove("hidden");
  confirmationSection.classList.add("hidden");
  updateSummary();
  setStep(4);
  showMessage(guestMessage, "Data tamu berhasil disimpan.", true);
}

function handlePaymentSubmit(event) {
  event.preventDefault();

  const method = paymentMethodSelect.value;

  if (!method) {
    showMessage(paymentMessage, "Pilih metode pembayaran terlebih dahulu.");
    return;
  }

  const booking = {
    code: createBookingCode(),
    room: state.selectedRoom,
    checkIn: state.checkIn,
    checkOut: state.checkOut,
    nights: state.nights,
    guestCount: state.guestCount,
    guest: state.guest,
    paymentMethod: method,
    paymentTarget: getPaymentTarget(method),
    total: state.selectedRoom.price * state.nights,
    createdAt: new Date().toISOString()
  };

  localStorage.setItem("pianHotelLastBooking", JSON.stringify(booking));
  showConfirmation(booking);
  setStep(5);
  showMessage(paymentMessage, "Pembayaran berhasil dikonfirmasi secara simulasi.", true);
}

function renderPaymentInstruction() {
  const method = paymentMethodSelect.value;

  if (method === "Transfer Bank BCA") {
    paymentInstruction.innerHTML = `
      <div class="payment-method-card">
        <span class="ticket-label">Transfer Bank</span>
        <h3>Bank BCA</h3>
        <div class="payment-number">${BCA_ACCOUNT}</div>
        <p>Atas nama <strong>${BCA_ACCOUNT_NAME}</strong>. Setelah transfer, tekan tombol "Saya Sudah Bayar" untuk membuat e-tiket.</p>
      </div>
    `;
    return;
  }

  if (method === "QRIS") {
    paymentInstruction.innerHTML = `
      <div class="payment-method-card">
        <span class="ticket-label">QRIS Demo</span>
        <h3>Pindai QRIS</h3>
        <img class="qris-image" src="${QRIS_IMAGE}" alt="QRIS demo Pian Hotel">
        <p>QRIS ini adalah gambar demo untuk tugas kuliah dan tidak memproses pembayaran nyata.</p>
      </div>
    `;
    return;
  }

  paymentInstruction.textContent = "Pilih metode pembayaran untuk melihat instruksi.";
}

function getPaymentTarget(method) {
  if (method === "Transfer Bank BCA") {
    return `BCA ${BCA_ACCOUNT} a.n. ${BCA_ACCOUNT_NAME}`;
  }

  if (method === "QRIS") {
    return "QRIS Pian Hotel Demo";
  }

  return method;
}

function updateSummary() {
  if (!state.selectedRoom) {
    summaryBox.innerHTML = `<p>Pilih tanggal dan kamar untuk melihat ringkasan reservasi.</p>`;
    return;
  }

  const total = state.selectedRoom.price * state.nights;
  summaryBox.innerHTML = `
    <div class="summary-line"><span>Kamar</span><strong>${state.selectedRoom.name}</strong></div>
    <div class="summary-line"><span>Check-in</span><strong>${formatInputDate(state.checkIn)}</strong></div>
    <div class="summary-line"><span>Check-out</span><strong>${formatInputDate(state.checkOut)}</strong></div>
    <div class="summary-line"><span>Tamu</span><strong>${state.guestCount} orang</strong></div>
    <div class="summary-line"><span>Durasi</span><strong>${state.nights} malam</strong></div>
    <div class="summary-line summary-total"><span>Total</span><strong>${currency.format(total)}</strong></div>
  `;
}

function showConfirmation(booking) {
  confirmationSection.classList.remove("hidden");
  confirmationBox.innerHTML = `
    <article class="e-ticket" id="eTicket">
      <div class="ticket-head">
        <div>
          <span class="ticket-label">E-Tiket Pian Hotel</span>
          <h3>Reservasi Berhasil</h3>
        </div>
        <span class="booking-code">${booking.code}</span>
      </div>
      <div class="ticket-route">
        <div>
          <span>Check-in</span>
          <strong>${formatInputDate(booking.checkIn)}</strong>
        </div>
        <div class="ticket-divider" aria-hidden="true"></div>
        <div>
          <span>Check-out</span>
          <strong>${formatInputDate(booking.checkOut)}</strong>
        </div>
      </div>
      <div class="ticket-detail-grid">
        <div><span>Nama tamu</span><strong>${booking.guest.name}</strong></div>
        <div><span>Kamar</span><strong>${booking.room.name}</strong></div>
        <div><span>Jumlah tamu</span><strong>${booking.guestCount} orang</strong></div>
        <div><span>Durasi</span><strong>${booking.nights} malam</strong></div>
        <div><span>Pembayaran</span><strong>${booking.paymentMethod}</strong></div>
        <div><span>Status</span><strong>Lunas</strong></div>
      </div>
      ${getTicketPaymentMarkup(booking)}
      <div class="ticket-total">
        <span>Total pembayaran</span>
        <strong>${currency.format(booking.total)}</strong>
      </div>
      <p class="ticket-note">Tunjukkan e-tiket ini kepada resepsionis saat check-in. E-tiket ini dibuat otomatis untuk simulasi proyek reservasi hotel.</p>
    </article>
    <div class="summary-box ticket-summary">
      <div class="summary-line"><span>Email</span><strong>${booking.guest.email}</strong></div>
      <div class="summary-line"><span>Telepon</span><strong>${booking.guest.phone}</strong></div>
      <div class="summary-line"><span>Dibuat</span><strong>${dateFormat.format(new Date(booking.createdAt))}</strong></div>
    </div>
  `;
}

function getTicketPaymentMarkup(booking) {
  if (booking.paymentMethod === "QRIS") {
    return `
      <div class="ticket-payment-proof">
        <img class="qris-image ticket-qris" src="${QRIS_IMAGE}" alt="QRIS demo Pian Hotel">
        <p>Pembayaran via QRIS demo Pian Hotel.</p>
      </div>
    `;
  }

  return `
    <div class="ticket-bank-box">
      <span>Tujuan pembayaran</span>
      <strong>${booking.paymentTarget || `BCA ${BCA_ACCOUNT} a.n. ${BCA_ACCOUNT_NAME}`}</strong>
    </div>
  `;
}

function printTicket() {
  if (!confirmationSection.classList.contains("hidden")) {
    window.print();
  }
}

function restoreLastBooking() {
  const saved = localStorage.getItem("pianHotelLastBooking");

  if (!saved) {
    return;
  }

  try {
    const booking = JSON.parse(saved);
    showConfirmation(booking);
  } catch {
    localStorage.removeItem("pianHotelLastBooking");
  }
}

function resetBooking() {
  localStorage.removeItem("pianHotelLastBooking");
  searchForm.reset();
  guestForm.reset();
  paymentForm.reset();
  state.checkIn = "";
  state.checkOut = "";
  state.guestCount = 2;
  state.nights = 0;
  state.selectedRoom = null;
  state.guest = null;
  document.querySelector("#guestCount").value = 2;
  hideSectionsAfterSearch();
  renderRooms(rooms);
  renderPaymentInstruction();
  updateSummary();
  clearMessages();
  setStep(1);
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function hideSectionsAfterSearch() {
  guestSection.classList.add("hidden");
  paymentSection.classList.add("hidden");
  confirmationSection.classList.add("hidden");
}

function showMessage(element, message, success = false) {
  element.textContent = message;
  element.classList.toggle("success", success);
}

function clearMessages() {
  [searchMessage, guestMessage, paymentMessage].forEach((element) => {
    showMessage(element, "");
  });
}

function setStep(activeStep) {
  document.querySelectorAll("[data-step-indicator]").forEach((item) => {
    item.classList.toggle("active", Number(item.dataset.stepIndicator) === activeStep);
  });
}

function createBookingCode() {
  const datePart = toDateInputValue(new Date()).replaceAll("-", "");
  const randomPart = Math.floor(1000 + Math.random() * 9000);
  return `PIAN-${datePart}-${randomPart}`;
}

function parseInputDate(value) {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(year, month - 1, day);
}

function stripTime(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function toDateInputValue(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatInputDate(value) {
  return dateFormat.format(parseInputDate(value));
}

initReservationPage();
